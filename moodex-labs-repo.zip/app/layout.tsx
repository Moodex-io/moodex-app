export const metadata = {
  title: process.env.NEXT_PUBLIC_SITE_NAME || "Moodex Labs",
  description: "The crypto mood console — fast, clear, and fun.",
};

import "./globals.css";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="bg-night text-white">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}

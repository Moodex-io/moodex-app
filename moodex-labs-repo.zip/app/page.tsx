import Header from "@/components/Header";
import Dashboard from "@/components/Dashboard";

export default function Page() {
  return (
    <main className="max-w-6xl mx-auto px-4 pb-24">
      <Header />
      <Dashboard />
    </main>
  );
}

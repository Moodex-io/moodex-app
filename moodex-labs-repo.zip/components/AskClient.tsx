"use client";

import { useState } from "react";

const WORKER_URL = process.env.NEXT_PUBLIC_WORKER_URL; // https://.../chat

export default function AskClient() {
  const [q, setQ] = useState("");
  const [lines, setLines] = useState<string[]>([
    "• Try prompts: Market mood • BTC today • Trending • Latest news",
  ]);
  const [busy, setBusy] = useState(false);

  const ask = async (question: string) => {
    if (!question.trim() || busy) return;
    setBusy(true);
    setLines((prev) => [...prev, `> ${question}`]);

    try {
      const res = await fetch(WORKER_URL!, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ question }),
      });

      let reply = "…";
      const txt = await res.text();
      try {
        const data = JSON.parse(txt);
        reply = data?.answer || data?.message || data?.reply || "…";
      } catch {
        reply = txt || "…";
      }
      setLines((prev) => [...prev, reply]);
    } catch {
      setLines((prev) => [...prev, "Network hiccup. Try again in a moment."]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="h-[260px] overflow-y-auto rounded-xl bg-black/30 border border-cyan-400/10 p-3 text-[13px] leading-6 text-cyan-100/90">
        {lines.map((l, i) => (
          <div key={i} className="mb-1 whitespace-pre-wrap">{l}</div>
        ))}
      </div>

      <div className="flex gap-2">
        <input
          className="flex-1 rounded-xl bg-black/40 border border-cyan-400/20 px-3 py-2 outline-none text-sm placeholder:text-cyan-200/50"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && ask(q) && setQ("")}
          placeholder="> Type your question…"
        />
        <button
          onClick={() => (ask(q), setQ(""))}
          disabled={busy}
          className="rounded-xl px-4 py-2 text-sm font-bold bg-cyan-500/20 border border-cyan-400/40 hover:bg-cyan-400/25 disabled:opacity-60"
        >
          Ask Mood-E
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {["Market mood","BTC today","ETH today","SOL today","Trending","Latest news","Top movers","Fear & Greed"].map((label) => (
          <button
            key={label}
            onClick={() => ask(label)}
            className="text-xs rounded-full border border-cyan-400/25 bg-black/30 px-3 py-1 hover:bg-black/40"
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}

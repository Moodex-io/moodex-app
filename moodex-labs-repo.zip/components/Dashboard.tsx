"use client";

import AskClient from "./AskClient";

export default function Dashboard() {
  return (
    <section id="console" className="mt-8">
      <div className="rounded-2xl border border-cyan-400/20 bg-[#0a161a]/60 shadow-[0_0_80px_rgba(16,185,129,0.12)] p-4 sm:p-6">
        <div className="text-center text-cyan-200/90 text-sm mb-3">
          MOOD-E online. Ask “market mood”, “BTC today”, or tap a quick prompt.
        </div>
        <AskClient />
      </div>
      <div id="join" className="text-center text-xs text-cyan-200/60 mt-6">
        The Mood of Crypto — at a glance. Join the Moodex Beta below.
      </div>
    </section>
  );
}

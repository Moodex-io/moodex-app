"use client";

const NAME = process.env.NEXT_PUBLIC_SITE_NAME || "MOODEX LABS";

export default function Header() {
  return (
    <header className="pt-10 pb-6 text-center">
      <h1 className="text-4xl sm:text-6xl font-black tracking-[0.08em]">
        <span className="bg-gradient-to-r from-cyan-300 via-sky-400 to-fuchsia-400 bg-clip-text text-transparent">
          {NAME}
        </span>
      </h1>
      <p className="mt-3 text-cyan-200/80 text-sm sm:text-base">
        INSTANT MARKET VIBES • TRENDS & HEADLINES • BUILT FOR SPEED
      </p>
      <div className="mt-6 flex items-center justify-center gap-3">
        <a
          href="#console"
          className="rounded-xl px-4 py-2 text-sm font-bold bg-cyan-500/20 border border-cyan-400/40 hover:bg-cyan-400/25 transition"
        >
          OPEN THE CONSOLE
        </a>
        <a
          href="#join"
          className="rounded-xl px-4 py-2 text-sm font-bold bg-fuchsia-500/20 border border-fuchsia-400/40 hover:bg-fuchsia-400/25 transition"
        >
          JOIN THE BETA
        </a>
      </div>
    </header>
  );
}
